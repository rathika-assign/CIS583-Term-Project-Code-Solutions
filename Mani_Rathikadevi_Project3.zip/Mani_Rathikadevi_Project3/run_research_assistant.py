from research_assistant import ResearchAssistant

# Provide your PDF/TXT file paths
file_paths = [
    r"C:\Users\rathi\langchain\CIS585-AdvAI-W25-L7-Neural-Networks.pdf"
]

# Initialize the research assistant
assistant = ResearchAssistant(file_paths)

print("Research Assistant is ready! Type your question or 'exit' to quit.\n")

while True:
    user_input = input("You: ")
    if user_input.lower() in ["exit", "quit"]:
        print("Assistant: Goodbye!")
        break

    answer = assistant.ask(user_input)
    print("Assistant:", answer)
