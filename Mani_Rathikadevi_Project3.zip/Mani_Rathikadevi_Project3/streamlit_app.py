import streamlit as st
from pathlib import Path
import tempfile
import os
import json
from research_agent import ResearchAssistant

st.set_page_config(page_title="Local Research Assistant", layout="wide")

st.title("Local Research Assistant (LLaMA3 + Ollama + FAISS)")

uploaded = st.file_uploader("Upload PDF or TXT files (you can upload multiple)", accept_multiple_files=True, type=["pdf", "txt"])

# temp save uploaded files
file_paths = []
if uploaded:
    tmpdir = Path(tempfile.gettempdir()) / "rra_uploads"
    tmpdir.mkdir(parents=True, exist_ok=True)
    for f in uploaded:
        out_path = tmpdir / f.name
        with open(out_path, "wb") as fh:
            fh.write(f.getbuffer())
        file_paths.append(str(out_path))

# fallback: use default file path if user didn't upload
if not uploaded:
    st.info("No files uploaded — using default PDF path. Upload to override.")
    default = r"C:\Users\rathi\langchain\CIS585-AdvAI-W25-L7-Neural-Networks.pdf"
    if Path(default).exists():
        file_paths = [default]
    else:
        st.warning("Default file not found — upload a PDF or TXT to proceed.")

st.write("Files to load:")
for p in file_paths:
    st.write("-", p)

use_cache = st.checkbox("Use FAISS cache (if available)", value=True)
k = st.slider("Number of retrieved chunks (k)", min_value=1, max_value=6, value=3)

if st.button("Build Assistant"):
    if not file_paths:
        st.error("No files to load. Upload files or ensure default path exists.")
    else:
        with st.spinner("Building assistant (loading, chunking, embedding)... this can take time"):
            assistant = ResearchAssistant(file_paths, k=k, use_faiss_cache=use_cache)
            st.success("Assistant built. You can ask questions now.")
            st.session_state["assistant"] = assistant

if "assistant" in st.session_state:
    assistant = st.session_state["assistant"]
    q = st.text_input("Ask a question about the loaded documents")
    if st.button("Ask") and q.strip():
        with st.spinner("Retrieving and querying LLaMA3..."):
            answer = assistant.ask(q)
            st.subheader("Answer")
            st.write(answer)

            # show last log lines
            try:
                logs = list(Path("logs").glob("session_*.jsonl"))
                if logs:
                    latest = sorted(logs)[-1]
                    st.subheader("Last interaction (log preview)")
                    with open(latest, "r", encoding="utf-8") as fh:
                        lines = fh.readlines()
                        last = json.loads(lines[-1])
                        st.json(last)
            except Exception as e:
                st.write("Could not read logs:", e)

else:
    st.info("Build the assistant first.")
