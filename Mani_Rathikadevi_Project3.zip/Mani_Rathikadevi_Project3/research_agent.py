"""
ResearchAssistant
- supports .txt and .pdf (UnstructuredPDFLoader)
- creates FAISS via OllamaEmbeddings
- ask(question) returns string answer
- logs queries to logs/session_<timestamp>.jsonl
- optional: save/load FAISS index to avoid recomputing (simple toggle)
"""

import os
import json
import time
from datetime import datetime
from pathlib import Path

from langchain_community.document_loaders import TextLoader, UnstructuredPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaEmbeddings, ChatOllama
from langchain_community.vectorstores import FAISS

LOG_DIR = Path("logs")
FAISS_DIR = Path("faiss_index")

class ResearchAssistant:
    def __init__(self, file_paths, k=3, use_faiss_cache=True):
        """
        file_paths: list of file paths (.pdf or .txt)
        k: number of retrieved chunks
        use_faiss_cache: if True and a saved index exists, load it instead of recomputing embeddings.
        """
        self.file_paths = file_paths
        self.k = k
        self.use_faiss_cache = use_faiss_cache
        LOG_DIR.mkdir(exist_ok=True)
        FAISS_DIR.mkdir(exist_ok=True)

        # load/split
        self.chunks = self._load_and_split()

        # build or load vectorstore
        self.vectorstore = self._create_vectorstore()

        # LLM
        self.llm = ChatOllama(model="llama3")

        # session logfile
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session_log = LOG_DIR / f"session_{ts}.jsonl"

    def _load_and_split(self):
        docs = []
        for path in self.file_paths:
            if not os.path.exists(path):
                print(f"[WARN] File not found, skipping: {path}")
                continue
            ext = os.path.splitext(path)[1].lower()
            try:
                if ext == ".txt":
                    loader = TextLoader(path)
                elif ext == ".pdf":
                    loader = UnstructuredPDFLoader(path)
                else:
                    print(f"[WARN] Unsupported file type, skipping: {path}")
                    continue
                loaded = loader.load()
                docs.extend(loaded)
                print(f"[INFO] Loaded {len(loaded)} Document objects from {path}")
            except Exception as e:
                print(f"[ERROR] Loading {path} failed: {e}")

        splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
        chunks = splitter.split_documents(docs)
        print(f"[INFO] Created {len(chunks)} chunks from documents")
        return chunks

    def _create_vectorstore(self):
        # If cache requested and saved index exists, try to load
        if self.use_faiss_cache and FAISS_DIR.exists() and any(FAISS_DIR.iterdir()):
            try:
                print("[INFO] Loading FAISS index from disk...")
                embeddings = OllamaEmbeddings(model="nomic-embed-text")
                vs = FAISS.load_local(str(FAISS_DIR), embeddings)
                print("[INFO] FAISS index loaded.")
                return vs
            except Exception as e:
                print(f"[WARN] Could not load FAISS index: {e}. Rebuilding.")

        print("[INFO] Creating FAISS index from chunks (this may take a while)...")
        embeddings = OllamaEmbeddings(model="nomic-embed-text")
        vs = FAISS.from_documents(self.chunks, embeddings)
        # Save local copy
        try:
            vs.save_local(str(FAISS_DIR))
            print("[INFO] FAISS index saved to", FAISS_DIR)
        except Exception as e:
            print("[WARN] Could not save FAISS index:", e)
        return vs

    def ask(self, question: str):
        # Retrieve
        try:
            docs = self.vectorstore.similarity_search(question, k=self.k)
        except Exception as e:
            return f"[ERROR] Retrieval failed: {e}"

        if not docs:
            return "No relevant information found."

        # Build context with small previews (for logging) and full content for prompt
        previews = [d.page_content[:400].replace("\n", " ") for d in docs]  # short preview
        context_full = "\n\n".join([d.page_content for d in docs])

        prompt = (
            "Use the following context to answer concisely:\n"
            f"{context_full}\n\n"
            f"Question: {question}"
        )

        # Call LLM
        try:
            response = self.llm.invoke(prompt)
            answer = response.content
        except Exception as e:
            answer = f"[ERROR] LLM query failed: {e}"

        # Log the interaction
        entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "question": question,
            "retrieved_previews": previews,
            "answer": (answer if isinstance(answer, str) else str(answer))
        }
        try:
            with open(self.session_log, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            print(f"[WARN] Could not write log: {e}")

        return answer
