import os
from pathlib import Path
from langchain_community.document_loaders import TextLoader, UnstructuredPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaEmbeddings, ChatOllama
from langchain_community.vectorstores import FAISS
class ResearchAssistant:
    def __init__(self, file_paths):
        self.file_paths = file_paths
        self.faiss_index_path = Path("./faiss_index")  # FAISS storage path
        print("[INFO] Loading documents...")
        self.chunks = self._load_and_split()
        print("[INFO] Checking for existing FAISS index...")
        self.vectorstore = self._create_vectorstore()
        # Initialize LLaMA 3 model via Ollama
        self.llm = ChatOllama(model="llama3")
        print("[INFO] Research Assistant Ready. Type your question or 'exit' to quit.")
    # Load documents and split into chunks
    def _load_and_split(self):
        docs = []
        for path in self.file_paths:
            ext = os.path.splitext(path)[1].lower()
            if ext == ".txt":
                loader = TextLoader(path)
            elif ext == ".pdf":
                loader = UnstructuredPDFLoader(path)
            else:
                print(f"[WARN] Skipping unsupported file type: {path}")
                continue
            try:
                docs += loader.load()
                print(f"[INFO] Loaded {len(docs)} document(s) from: {path}")
            except Exception as e:
                print(f"[ERROR] Failed to load {path}: {e}")
        print("[INFO] Splitting into text chunks...")
        splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
        chunks = splitter.split_documents(docs)
        print(f"[INFO] {len(chunks)} chunks created.")
        return chunks

    # Create or load FAISS vectorstore
    def _create_vectorstore(self):
        embeddings = OllamaEmbeddings(model="nomic-embed-text")
        if self.faiss_index_path.exists() and any(self.faiss_index_path.iterdir()):
            print("[INFO] Loading existing FAISS index...")
            vectorstore = FAISS.load_local(
            str(self.faiss_index_path), 
            embeddings,
                allow_dangerous_deserialization=True  # <-- add this
        )
        else:
            print("[WARN] No existing FAISS index found. Creating a new one...")
            vectorstore = FAISS.from_documents(self.chunks, embeddings)
            self.faiss_index_path.mkdir(exist_ok=True)
            vectorstore.save_local(str(self.faiss_index_path))
            print(f"[INFO] FAISS index saved to {self.faiss_index_path}")

        return vectorstore

    # Ask a question and get answer
    # ----------------------------
    def ask(self, question: str, top_k: int = 3):
        print(f"[INFO] Retrieving top {top_k} relevant chunks...")
        results = self.vectorstore.similarity_search(question, k=top_k)
        context = "\n".join([doc.page_content for doc in results])

        prompt = f"Use the following context to answer concisely:\n{context}\nQuestion: {question}"

        print("[INFO] Querying LLaMA 3...")
        try:
            response = self.llm.invoke(prompt).content
            return response
        except Exception as e:
            print(f"[ERROR] LLaMA query failed: {e}")
            return "Sorry, I could not generate an answer."
